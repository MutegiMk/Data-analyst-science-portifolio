from setuptools import setup

setup(name='tesh_GauBiprop',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['tesh_GauBiprop'],
      author= 'Emmanuel Mutegi',
      author_email= 'emmamutegi97@gmail.com',
      zip_safe=False)
